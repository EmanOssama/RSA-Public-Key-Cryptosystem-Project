﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RSA
{
   public class divide
    {
       public string qoutient = "";
       public string remainder = "";
       public divide() { }
    }
}
